KTECH Orbit - Claude review package

Source: KTECH_Orbit_Emergency_Restaurants_Working_Demo (1).html
Original source size: 4,105,751 bytes
This package was generated from the ORIGINAL HTML file, not the separately reviewed demo.
Original file was not modified.

Files:
- index.html: converted entry point
- css/: 12 extracted style blocks, in original order
- js/: 9 extracted executable script blocks, in original order
- assets/: 8 distinct embedded image assets (9 occurrences)
- review/: 71 numbered, small text parts for Claude to read via GitHub
- FILE_MANIFEST.txt: inventory

IMPORTANT: This is a code-review conversion, NOT a verified production build.
Opening index.html via file:// can behave differently from a hosted web server.
Test every map, navigation, chatbot, emergency, and restaurant feature before deploying.
Some code can depend on inline script execution or original data URL behavior.
Do not replace the original site until browser testing passes.

To upload to GitHub, extract this ZIP, and upload the contents under
ktech-orbit-split/ while keeping your original HTML as a backup.
Avoid committing API keys, credentials, or private student data.
